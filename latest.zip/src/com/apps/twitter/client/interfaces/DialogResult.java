package com.apps.twitter.client.interfaces;

import com.apps.twitter.client.model.Tweet;

public interface DialogResult {
         void finish(Tweet result);
}
